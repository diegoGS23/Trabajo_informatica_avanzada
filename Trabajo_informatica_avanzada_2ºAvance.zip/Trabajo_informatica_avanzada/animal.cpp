#include "animal.h"
#include <QVector>
#include <QDebug>

Animal::Animal(int id, QString especie, QString nombre, int edad):id(id),especie(especie),nombre(nombre),edad(edad) {
    this->id=id;
    this->especie=especie;
    this->nombre=nombre;
    this->edad=edad;
}

int Animal::getId(){
    return id;
}

QString Animal::getEspecie(){
    return especie;
}

QString Animal::getNombre(){
    return nombre;
}

int Animal::getEdad(){
    return edad;
}

