#include "mainappwindow.h"
#include "ui_mainappwindow.h"
#include "santuario.h"

MainAppWindow::MainAppWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainAppWindow)
    ,santuario("Gaia","Ávila")
{
    ui->setupUi(this);

    santuario.agregarRecinto(1,"Acuario",10);
    santuario.agregarRecinto(2,"Bosque",16);
    santuario.agregarRecinto(3,"Pradera",22);

    mostrarRecintos();

    ui->tableWidgetRecintos->setColumnCount(3);

    QStringList cabeceras;
    cabeceras << "ID" << "Nombre" << "Capacidad";

    ui->tableWidgetRecintos->setHorizontalHeaderLabels(cabeceras);
}

MainAppWindow::~MainAppWindow()
{
    delete ui;
}

QVector<Recinto> MainAppWindow::getRecintos()
{
    return santuario.getRecintos();
}

void MainAppWindow::mostrarRecintos(){
    ui->tableWidgetRecintos->setRowCount(0);

    QVector<Recinto> lista=santuario.getRecintos();

    for(int i=0; i<lista.size(); i++){
        ui->tableWidgetRecintos->insertRow(i);

        ui->tableWidgetRecintos->setItem(i,0,new QTableWidgetItem(QString::number(lista[i].getId())));

        ui->tableWidgetRecintos->setItem(i,1,new QTableWidgetItem(lista[i].getNombre()));

        ui->tableWidgetRecintos->setItem(i,2,new QTableWidgetItem(QString::number(lista[i].getCapacidad())));
    }

}

void MainAppWindow::on_verAnimales_clicked()
{
    int fila =ui->tableWidgetRecintos->currentRow();

    if(fila < 0)
        return;

    QVector<Recinto> lista =santuario.getRecintos();
    Recinto seleccionado =lista[fila];
    animalesWindow *w =new animalesWindow(seleccionado);

    w->show();
}

