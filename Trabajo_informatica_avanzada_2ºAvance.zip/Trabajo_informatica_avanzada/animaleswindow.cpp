#include "animaleswindow.h"
#include "ui_animaleswindow.h"
#include "animal.h"

animalesWindow::animalesWindow(Recinto recinto,QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::animalesWindow)
    ,recintoActual(recinto)

{
    ui->setupUi(this);

    recintoActual.agregarAnimal(1,"Lobo","Rex",4);
    recintoActual.agregarAnimal(2,"Zorro","Toby",5);

    mostrarAnimales();

    ui->tableWidgetAnimales->setColumnCount(4);

    QStringList cabeceras;
    cabeceras << "ID" << "Especie" << "Nombre" << "Edad";

    ui->tableWidgetAnimales->setHorizontalHeaderLabels(cabeceras);
}

animalesWindow::~animalesWindow()
{
    delete ui;
}

QVector<Animal> animalesWindow::getAnimales()
{
    return recintoActual.getAnimales();
}

void animalesWindow::mostrarAnimales(){

    ui->tableWidgetAnimales->setRowCount(0);

    QVector<Animal> lista=recintoActual.getAnimales();

    for(int i=0; i<lista.size(); i++){
        ui->tableWidgetAnimales->insertRow(i);


        ui->tableWidgetAnimales->setItem(i,0,new QTableWidgetItem(QString::number(lista[i].getId())));

        ui->tableWidgetAnimales->setItem(i,1,new QTableWidgetItem(lista[i].getNombre()));

        ui->tableWidgetAnimales->setItem(i,2,new QTableWidgetItem(lista[i].getEspecie()));

         ui->tableWidgetAnimales->setItem(i,4,new QTableWidgetItem(QString::number(lista[i].getEdad())));
    }
}



