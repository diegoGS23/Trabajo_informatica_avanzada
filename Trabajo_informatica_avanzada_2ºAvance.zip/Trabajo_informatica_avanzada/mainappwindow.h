#ifndef MAINAPPWINDOW_H
#define MAINAPPWINDOW_H

#include <QMainWindow>
#include "santuario.h"
#include "recinto.h"
#include "animal.h"
#include "animaleswindow.h"

namespace Ui {
class MainAppWindow;
}

class MainAppWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainAppWindow(QWidget *parent = nullptr);
    ~MainAppWindow();

private slots:
    QVector<Recinto> getRecintos();
    void mostrarRecintos();
    void on_verAnimales_clicked();

private:
    Ui::MainAppWindow *ui;

    Santuario santuario;
    QVector<Recinto> recintos;
    QVector<Animal> animales;
};

#endif // MAINAPPWINDOW_H
