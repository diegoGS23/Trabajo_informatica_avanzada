#include "animaleswindow.h"
#include "ui_animaleswindow.h"
#include "animal.h"
#include "alimentacioneswindow.h"

animalesWindow::animalesWindow(Recinto recinto,QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::animalesWindow)
    ,recintoActual(recinto)

{
    ui->setupUi(this);

    mostrarAnimales();

    ui->tableWidgetAnimales->setColumnCount(4);

    QStringList cabeceras;
    cabeceras << "ID" << "Nombre" << "Especie" << "Edad";

    ui->tableWidgetAnimales->setHorizontalHeaderLabels(cabeceras);

}

animalesWindow::~animalesWindow()
{
    delete ui;
}

QVector<Animal> animalesWindow::getAnimales()
{
    return recintoActual.getAnimales();
}

void animalesWindow::mostrarAnimales(){

    ui->tableWidgetAnimales->setRowCount(0);

    QVector<Animal> lista=recintoActual.getAnimales();

    for(int i=0; i<lista.size(); i++){
        ui->tableWidgetAnimales->insertRow(i);

        ui->tableWidgetAnimales->setItem(i,0,new QTableWidgetItem(QString::number(lista[i].getId())));

        ui->tableWidgetAnimales->setItem(i,1,new QTableWidgetItem(lista[i].getNombre()));

        ui->tableWidgetAnimales->setItem(i,2,new QTableWidgetItem(lista[i].getEspecie()));

        ui->tableWidgetAnimales->setItem(i,3,new QTableWidgetItem(QString::number(lista[i].getEdad())));
    }
}

void animalesWindow::on_verAlimentos_clicked()
{
    int fila =ui->tableWidgetAnimales->currentRow();

    if(fila < 0)
        return;

    Animal seleccionado =recintoActual.getAnimales()[fila];
    alimentacionesWindow *w =new alimentacionesWindow(seleccionado);

    w->show();
}

