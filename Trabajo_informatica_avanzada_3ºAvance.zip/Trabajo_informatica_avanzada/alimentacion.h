#ifndef ALIMENTACION_H
#define ALIMENTACION_H

#include <QVector>

class Alimentacion
{
public:
    Alimentacion(int id, QString comida);

    int getId();
    QString getComida();

    //void agregarComida();

private:
    int id;
    QString comida;
};

#endif // ALIMENTACION_H
