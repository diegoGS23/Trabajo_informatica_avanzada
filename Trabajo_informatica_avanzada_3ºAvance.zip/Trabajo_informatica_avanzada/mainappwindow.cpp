#include "mainappwindow.h"
#include "ui_mainappwindow.h"
#include "santuario.h"
#include "ui_animaleswindow.h"
#include "animaleswindow.h"
#include "animal.h"
#include "alimentacioneswindow.h""
#include "ui_alimentacioneswindow.h"

MainAppWindow::MainAppWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainAppWindow)
    ,santuario("Gaia","Ávila")
{
    ui->setupUi(this);

    Recinto r1(1,"Acuario",10);
    Recinto r2(2,"Bosque",16);
    Recinto r3(3,"Jungla",22);

    Animal a1(1473,"Pez payaso","Nemo",2);
    Animal a2(1282,"Lobo ibérico","Rex",4);
    Animal a3(2547,"Zorro ibérico","Toby",5);
    Animal a4(1119,"Pantera","Baguira",5);

    r1.agregarAnimal(a1);
    r2.agregarAnimal(a2);
    r2.agregarAnimal(a3);
    r3.agregarAnimal(a4);

    santuario.agregarRecinto(r1);
    santuario.agregarRecinto(r2);
    santuario.agregarRecinto(r3);

    mostrarRecintos();

    a1.agregarAlimento(14,"Zooplancton");
    a2.agregarAlimento(2,"Carnaza");
    a3.agregarAlimento(4,"Carne de pollo");
    a4.agregarAlimento(2,"Carnaza");



    ui->tableWidgetRecintos->setColumnCount(3);

    QStringList cabeceras;
    cabeceras << "ID" << "Nombre" << "Capacidad";

    ui->tableWidgetRecintos->setHorizontalHeaderLabels(cabeceras);
}

MainAppWindow::~MainAppWindow()
{
    delete ui;
}

QVector<Recinto> MainAppWindow::getRecintos()
{
    return santuario.getRecintos();
}

void MainAppWindow::mostrarRecintos(){
    ui->tableWidgetRecintos->setRowCount(0);

    QVector<Recinto> lista=santuario.getRecintos();

    for(int i=0; i<lista.size(); i++){
        ui->tableWidgetRecintos->insertRow(i);

        ui->tableWidgetRecintos->setItem(i,0,new QTableWidgetItem(QString::number(lista[i].getId())));

        ui->tableWidgetRecintos->setItem(i,1,new QTableWidgetItem(lista[i].getNombre()));

        ui->tableWidgetRecintos->setItem(i,2,new QTableWidgetItem(QString::number(lista[i].getCapacidad())));
    }

}

void MainAppWindow::on_verAnimales_clicked()
{
    int fila =ui->tableWidgetRecintos->currentRow();

    if(fila < 0)
        return;

    Recinto seleccionado =santuario.getRecintos()[fila];
    animalesWindow *w =new animalesWindow(seleccionado);

    w->show();
}

