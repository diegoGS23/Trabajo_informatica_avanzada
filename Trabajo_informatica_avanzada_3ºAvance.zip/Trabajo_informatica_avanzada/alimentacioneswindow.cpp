#include "alimentacioneswindow.h"
#include "ui_alimentacioneswindow.h"
#include "animal.h"

alimentacionesWindow::alimentacionesWindow(Animal animal,QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::alimentacionesWindow)
    , animalActual(animal)
{
    ui->setupUi(this);

    ui->tableWidgetAlimentos->setColumnCount(2);

    QStringList cabeceras;
    cabeceras << "ID" << "Comida";

    ui->tableWidgetAlimentos->setHorizontalHeaderLabels(cabeceras);

    mostrarAlimentos();
}

alimentacionesWindow::~alimentacionesWindow()
{
    delete ui;
}

QVector<Alimentacion> alimentacionesWindow::getAlimentos()
{
    return animalActual.getAlimentos();
}

void alimentacionesWindow::mostrarAlimentos(){

    ui->tableWidgetAlimentos->setRowCount(0);

    QVector<Alimentacion> lista=animalActual.getAlimentos();

    for(int i=0; i<lista.size(); i++){
        ui->tableWidgetAlimentos->insertRow(i);

        ui->tableWidgetAlimentos->setItem(i,0,new QTableWidgetItem(QString::number(lista[i].getId())));

        ui->tableWidgetAlimentos->setItem(i,1,new QTableWidgetItem(lista[i].getComida()));
    }
}



